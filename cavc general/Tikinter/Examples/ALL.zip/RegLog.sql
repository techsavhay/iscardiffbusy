BEGIN TRANSACTION;
CREATE TABLE RegLog (
	regid int IDENTITY(1,1) PRIMARY KEY,
	email	varchar(255) NOT NULL,
	fullname	varchar(255) NOT NULL,
	Password	varchar(255) NOT NULL,
	confirmpassword	varchar(255) NOT NULL
);
INSERT INTO RegLog (Email,FullName,Password,ConfirmPassword) VALUES ('myname@name.com','my Name','password123','password123');
COMMIT;
